const { exec } = require('child_process');
const path = require('path');

exports.runCropRotation = (req, res) => {
  const scriptPath = path.join(__dirname, 'rl', 'train_agent.py');

  exec(`python3 "${scriptPath}"`, (error, stdout, stderr) => {
    if (error) {
      console.error(`Error: ${error.message}`);
      return res.status(500).json({ error: 'Python execution failed' });
    }
    if (stderr) {
      console.error(`Python stderr: ${stderr}`);
    }

    try {
      const output = JSON.parse(stdout);
      res.json(output);
    } catch (parseError) {
      console.error(`Parse error: ${parseError.message}`);
      res.status(500).json({ error: 'Failed to parse Python output' });
    }
  });
};
