import networkx as nx
import json
import os
import numpy as np
from collections import defaultdict

class CropRotationGraph:
    def __init__(self, crop_data_path):
        """
        Initialize a graph-based crop rotation recommendation system
        
        Args:
            crop_data_path: Path to the crop data JSON file
        """
        self.crop_data_path = crop_data_path
        self.crop_data = self._load_crop_data()
        self.G = nx.DiGraph()
        self.crop_index_map = {}
        self.index_crop_map = {}
        self._build_crop_maps()
        self.build_graph()
        
    def _load_crop_data(self):
        """Load crop data from JSON file"""
        with open(self.crop_data_path, 'r') as f:
            crop_data = json.load(f)
        return crop_data
    
    def _build_crop_maps(self):
        """Build mappings between crop names and indices"""
        # Create crop index mappings
        for i, crop in enumerate(self.crop_data):
            self.crop_index_map[crop['name']] = i
            self.index_crop_map[i] = crop['name']
    
    def build_graph(self):
        """Build a directed graph where:
           - Nodes are crops
           - Edges represent rotation suitability
           - Edge weights are rotation benefit scores
           - Edge attributes include seasonal constraints
        """
        # Add all crops as nodes
        for crop in self.crop_data:
            self.G.add_node(crop['name'], info=crop)
        
        # Add edges between crops with rotation benefits
        for prev_crop in self.crop_data:
            for next_crop in self.crop_data:
                # Skip self-rotation
                if prev_crop['name'] == next_crop['name']:
                    continue
                
                # Calculate rotation benefit
                benefit_score = self._calculate_rotation_benefit(prev_crop, next_crop)
                
                # Add edge if there's a benefit
                if benefit_score > 0:
                    # Get valid months for this rotation
                    valid_months = self._get_valid_months(prev_crop, next_crop)
                    valid_seasons = self._get_valid_seasons(valid_months)
                    
                    self.G.add_edge(
                        prev_crop['name'], 
                        next_crop['name'], 
                        weight=benefit_score,
                        valid_months=valid_months,
                        valid_seasons=valid_seasons
                    )
    
    def _calculate_rotation_benefit(self, prev_crop, next_crop):
        """Calculate the benefit score of planting next_crop after prev_crop"""
        # Base score
        score = 5.0
        
        # Family diversity (different families break pest cycles)
        # Assume 'family' exists in crop data, modify as needed
        if prev_crop.get('family', '') != next_crop.get('family', '') and prev_crop.get('family') and next_crop.get('family'):
            score += 1.5
        
        # Nutrient complementarity (e.g., legumes fix nitrogen)
        if prev_crop.get('nutrient_effect') == 'nitrogen_fixing' and next_crop.get('nutrient_needs') == 'high_nitrogen':
            score += 2.0
        
        # Root depth variation (different root depths use soil better)
        if prev_crop.get('root_depth') != next_crop.get('root_depth') and prev_crop.get('root_depth') and next_crop.get('root_depth'):
            score += 1.0
        
        # Season compatibility
        compatible_seasons = self._check_season_compatibility(prev_crop, next_crop)
        if compatible_seasons:
            score += 1.0
            
        return score
    
    def _check_season_compatibility(self, prev_crop, next_crop):
        """Check if there's appropriate seasonal progression from prev_crop to next_crop"""
        # Extract seasons info from crops
        prev_seasons = prev_crop.get('growing_seasons', [])
        next_seasons = next_crop.get('growing_seasons', [])
        
        # If either crop doesn't have season info, return True as default
        if not prev_seasons or not next_seasons:
            return True
            
        # Season progression (e.g., summer crop followed by fall crop)
        season_order = ['Spring', 'Summer', 'Fall', 'Winter']
        compatible_seasons = []
        
        for prev_season in prev_seasons:
            prev_idx = season_order.index(prev_season) if prev_season in season_order else -1
            if prev_idx >= 0:
                next_idx = (prev_idx + 1) % 4
                next_season = season_order[next_idx]
                if next_season in next_seasons:
                    compatible_seasons.append(next_season)
        
        return compatible_seasons
    
    def _get_valid_months(self, prev_crop, next_crop):
        """Determine which months are valid for planting next_crop after prev_crop"""
        # Get harvest months for prev_crop (default to all if not specified)
        prev_harvest_months = prev_crop.get('harvest_months', list(range(1, 13)))
        
        # Get planting months for next_crop (default to all if not specified)
        next_planting_months = next_crop.get('planting_months', list(range(1, 13)))
        
        # Return months that are valid (typically after harvest of prev_crop)
        valid_months = []
        for harvest_month in prev_harvest_months:
            # Add next 3 months after harvest as valid planting months
            for i in range(4):  # 0 to 3
                valid_month = (harvest_month + i) % 12
                if valid_month == 0:
                    valid_month = 12  # Convert 0 to 12 for December
                
                if valid_month in next_planting_months:
                    valid_months.append(valid_month)
        
        return sorted(list(set(valid_months)))
    
    def _get_valid_seasons(self, months):
        """Convert months to seasons"""
        seasons = set()
        for month in months:
            if month in [12, 1, 2]:
                seasons.add('Winter')
            elif month in [3, 4, 5]:
                seasons.add('Spring')
            elif month in [6, 7, 8]:
                seasons.add('Summer')
            else:  # 9, 10, 11
                seasons.add('Fall')
        return list(seasons)
    
    def recommend_next_crop(self, previous_crop, current_month=None, current_season=None, top_n=5):
        """
        Recommend the next best crops to plant after previous_crop
        
        Args:
            previous_crop: Name of the previously planted crop
            current_month: Current month (1-12)
            current_season: Current season (Spring, Summer, Fall, Winter)
            top_n: Number of recommendations to return
            
        Returns:
            List of recommended crops with scores and reasons
        """
        # Ensure we have either month or season (prioritize month if both provided)
        if not current_month and not current_season:
            raise ValueError("Either current_month or current_season must be provided")
        
        # Handle case where previous crop is not in our graph
        if previous_crop not in self.G:
            if current_month:
                return self._get_default_recommendations_by_month(current_month, top_n)
            else:
                return self._get_default_recommendations_by_season(current_season, top_n)
        
        # Get all possible next crops
        neighbors = list(self.G.neighbors(previous_crop))
        
        # Filter by valid month/season
        valid_crops = []
        for next_crop in neighbors:
            edge_data = self.G.get_edge_data(previous_crop, next_crop)
            
            # Determine if this crop is valid for the current month/season
            is_valid = False
            if current_month and current_month in edge_data['valid_months']:
                is_valid = True
            elif current_season and current_season in edge_data['valid_seasons']:
                is_valid = True
                
            if is_valid:
                # Get explanation for why this crop is recommended
                explanation = self._get_recommendation_reason(previous_crop, next_crop)
                valid_crops.append((next_crop, edge_data['weight'], explanation))
        
        # If no valid crops, return default recommendations
        if not valid_crops:
            if current_month:
                return self._get_default_recommendations_by_month(current_month, top_n)
            else:
                return self._get_default_recommendations_by_season(current_season, top_n)
        
        # Sort by weight and return top_n
        valid_crops.sort(key=lambda x: x[1], reverse=True)
        return valid_crops[:top_n]
    
    def _get_recommendation_reason(self, prev_crop, next_crop):
        """Generate a human-readable explanation for why next_crop is recommended after prev_crop"""
        prev_info = self.G.nodes[prev_crop]['info']
        next_info = self.G.nodes[next_crop]['info']
        reasons = []
        
        # Family diversity reason
        if prev_info.get('family', '') != next_info.get('family', '') and prev_info.get('family') and next_info.get('family'):
            reasons.append(f"Different plant family from {prev_crop} helps break pest cycles")
        
        # Nutrient complementarity reason
        if prev_info.get('nutrient_effect') == 'nitrogen_fixing':
            reasons.append(f"{prev_crop} fixed nitrogen in the soil which benefits {next_crop}")
        
        # Root depth reason
        if prev_info.get('root_depth') != next_info.get('root_depth') and prev_info.get('root_depth') and next_info.get('root_depth'):
            reasons.append(f"Different root depth from {prev_crop} helps utilize soil nutrients efficiently")
        
        # Season progression reason
        edge_data = self.G.get_edge_data(prev_crop, next_crop)
        if 'valid_seasons' in edge_data and edge_data['valid_seasons']:
            seasons_str = ", ".join(edge_data['valid_seasons'])
            reasons.append(f"Suitable for planting in {seasons_str} after harvesting {prev_crop}")
        
        # If no specific reasons, provide a general one
        if not reasons:
            reasons.append(f"Generally compatible with {prev_crop} in crop rotation")
            
        return reasons
    
    def _get_default_recommendations_by_month(self, month, top_n=5):
        """Get default recommendations for the given month when no previous crop data is available"""
        # Find crops that can be planted in this month
        suitable_crops = []
        
        for crop, data in self.G.nodes(data=True):
            crop_info = data['info']
            planting_months = crop_info.get('planting_months', [])
            
            if month in planting_months:
                # Use a base score plus any special considerations
                score = 5.0
                
                # Boost score for crops that are particularly well suited for the season
                season = self._month_to_season(month)
                if season in crop_info.get('best_seasons', []):
                    score += 1.5
                
                reason = [f"Suitable for planting in month {month} ({season})"]
                suitable_crops.append((crop, score, reason))
        
        # Sort by score and return top_n
        suitable_crops.sort(key=lambda x: x[1], reverse=True)
        return suitable_crops[:top_n]
    
    def _get_default_recommendations_by_season(self, season, top_n=5):
        """Get default recommendations for the given season when no previous crop data is available"""
        # Find crops that can be planted in this season
        suitable_crops = []
        
        for crop, data in self.G.nodes(data=True):
            crop_info = data['info']
            growing_seasons = crop_info.get('growing_seasons', [])
            
            if season in growing_seasons:
                # Use a base score plus any special considerations
                score = 5.0
                
                # Boost score for crops that are particularly well suited for the season
                if season in crop_info.get('best_seasons', []):
                    score += 1.5
                
                reason = [f"Suitable for planting in {season}"]
                suitable_crops.append((crop, score, reason))
        
        # Sort by score and return top_n
        suitable_crops.sort(key=lambda x: x[1], reverse=True)
        return suitable_crops[:top_n]
    
    def _month_to_season(self, month):
        """Convert month to season"""
        if month in [12, 1, 2]:
            return 'Winter'
        elif month in [3, 4, 5]:
            return 'Spring'
        elif month in [6, 7, 8]:
            return 'Summer'
        else:
            return 'Fall'
    
    def get_optimal_rotation_sequence(self, starting_crop=None, starting_month=None, starting_season=None, sequence_length=3):
        """
        Generate an optimal crop rotation sequence
        
        Args:
            starting_crop: First crop in the sequence (optional)
            starting_month: Month to start planting (1-12)
            starting_season: Season to start planting
            sequence_length: Number of crops in the rotation sequence
            
        Returns:
            List of crops and planting times
        """
        # Validate inputs
        if not starting_month and not starting_season:
            raise ValueError("Either starting_month or starting_season must be provided")
        
        current_month = starting_month
        current_season = starting_season if starting_season else self._month_to_season(starting_month)
        best_path = []
        
        # Start with provided crop or find best crop for starting time
        if starting_crop and starting_crop in self.G:
            current_crop = starting_crop
            planting_time = current_month if current_month else current_season
            best_path.append((current_crop, planting_time))
        else:
            # Get initial crop recommendation
            if current_month:
                initial_options = self._get_default_recommendations_by_month(current_month, top_n=1)
            else:
                initial_options = self._get_default_recommendations_by_season(current_season, top_n=1)
                
            if not initial_options:
                return []
            
            current_crop = initial_options[0][0]
            planting_time = current_month if current_month else current_season
            best_path.append((current_crop, planting_time))
        
        # Build the rest of the sequence
        for i in range(sequence_length - 1):
            # Find when current crop will be harvested
            crop_info = self.G.nodes[current_crop]['info']
            growth_time = crop_info.get('growth_time_months', 3)  # Default to 3 months
            
            # Calculate next planting time
            if current_month:
                # Calculate next month
                next_month = (current_month + growth_time) % 12
                if next_month == 0:
                    next_month = 12
                next_season = self._month_to_season(next_month)
            else:
                # Move to next season
                seasons = ['Spring', 'Summer', 'Fall', 'Winter']
                current_idx = seasons.index(current_season)
                next_idx = (current_idx + 1) % 4
                next_season = seasons[next_idx]
                next_month = None
            
            # Get next crop recommendation
            if next_month:
                next_options = self.recommend_next_crop(current_crop, current_month=next_month, top_n=1)
            else:
                next_options = self.recommend_next_crop(current_crop, current_season=next_season, top_n=1)
                
            if not next_options:
                break
                
            next_crop = next_options[0][0]
            planting_time = next_month if next_month else next_season
            best_path.append((next_crop, planting_time))
            
            # Update for next iteration
            current_crop = next_crop
            current_month = next_month
            current_season = next_season
            
        return best_path
    
    def get_all_crops(self):
        """Get list of all crops in the dataset"""
        return list(self.G.nodes())
    
    def export_graph_to_json(self, output_path):
        """Export the graph to a JSON file for visualization"""
        graph_data = {
            "nodes": [],
            "links": []
        }
        
        # Add nodes
        for node, data in self.G.nodes(data=True):
            graph_data["nodes"].append({
                "id": node,
                "name": node,
                "family": data["info"].get("family", "Unknown"),
                "seasons": data["info"].get("growing_seasons", [])
            })
        
        # Add links
        for source, target, data in self.G.edges(data=True):
            graph_data["links"].append({
                "source": source,
                "target": target,
                "weight": data["weight"],
                "valid_months": data["valid_months"],
                "valid_seasons": data["valid_seasons"]
            })
        
        # Write to file
        with open(output_path, 'w') as f:
            json.dump(graph_data, f, indent=2)
        
        return output_path