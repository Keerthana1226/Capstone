import os
import json
import argparse
from crop_rotation_graph import CropRotationGraph

def main():
    """Command-line interface for the crop rotation graph recommender"""
    parser = argparse.ArgumentParser(description='Smart Crop Rotation Assistant using Graph-based approach')
    parser.add_argument('--data', type=str, default='crop_data.json', help='Path to crop data JSON file')
    parser.add_argument('--previous', type=str, help='Previous crop planted')
    parser.add_argument('--month', type=int, choices=range(1, 13), help='Current month (1-12)')
    parser.add_argument('--season', type=str, choices=['Spring', 'Summer', 'Fall', 'Winter'], help='Current season')
    parser.add_argument('--top', type=int, default=5, help='Number of recommendations to display')
    parser.add_argument('--sequence', type=int, default=3, help='Generate rotation sequence of this length')
    parser.add_argument('--export', type=str, help='Export graph to JSON file at this path')
    
    args = parser.parse_args()
    
    # Ensure crop data file exists
    crop_data_path = args.data
    if not os.path.exists(crop_data_path):
        print(f"❌ Crop data file not found: {crop_data_path}")
        return
    
    # Initialize the graph system
    print(f"🌱 Building crop rotation graph from {crop_data_path}...")
    rotation_graph = CropRotationGraph(crop_data_path)
    
    # Print some graph statistics
    print(f"📊 Graph statistics:")
    print(f"   - Total crops: {len(rotation_graph.get_all_crops())}")
    print(f"   - Total rotation relationships: {len(rotation_graph.G.edges())}")
    
    # Export graph if requested
    if args.export:
        export_path = rotation_graph.export_graph_to_json(args.export)
        print(f"📤 Exported graph to {export_path}")
    
    # Get recommendations based on previous crop and current time
    if args.previous:
        print(f"\n🔍 Finding recommendations for what to plant after {args.previous}...")
        
        if not args.month and not args.season:
            print("⚠️ Please provide either --month or --season for recommendations")
            return
        
        try:
            if args.month:
                recommendations = rotation_graph.recommend_next_crop(
                    args.previous, 
                    current_month=args.month, 
                    top_n=args.top
                )
                time_str = f"month {args.month}"
            else:
                recommendations = rotation_graph.recommend_next_crop(
                    args.previous, 
                    current_season=args.season, 
                    top_n=args.top
                )
                time_str = f"{args.season} season"
                
            print(f"\n🌿 Top {len(recommendations)} recommendations for {time_str} after {args.previous}:")
            
            if not recommendations:
                print(f"⚠️ No recommendations found for {args.previous} in {time_str}")
            else:
                for i, (crop, score, reasons) in enumerate(recommendations, 1):
                    print(f"{i}. {crop} (score: {score:.2f})")
                    for reason in reasons:
                        print(f"   - {reason}")
        except KeyError:
            print(f"⚠️ Crop '{args.previous}' not found in the database")
    
    # Generate optimal rotation sequence
    if args.sequence > 0:
        print(f"\n🔄 Generating optimal {args.sequence}-crop rotation sequence...")
        
        if not args.month and not args.season:
            print("⚠️ Please provide either --month or --season for sequence generation")
            return
        
        try:
            sequence = rotation_graph.get_optimal_rotation_sequence(
                starting_crop=args.previous if args.previous else None,
                starting_month=args.month if args.month else None,
                starting_season=args.season if args.season else None,
                sequence_length=args.sequence
            )
            
            print(f"\n📋 Recommended {len(sequence)}-crop rotation sequence:")
            
            if not sequence:
                print("⚠️ Could not generate a rotation sequence with the given parameters")
            else:
                for i, (crop, planting_time) in enumerate(sequence, 1):
                    time_str = f"Month {planting_time}" if isinstance(planting_time, int) else planting_time
                    print(f"{i}. {crop} ({time_str})")
        except Exception as e:
            print(f"⚠️ Error generating rotation sequence: {str(e)}")
    
    # Interactive mode if no specific query was provided
    if not args.previous and args.sequence <= 0 and not args.export:
        interactive_mode(rotation_graph)

def interactive_mode(rotation_graph):
    """Run an interactive recommendation session"""
    print("\n🌱 Smart Crop Rotation Assistant - Interactive Mode 🌱")
    print("Enter 'q' at any prompt to quit")
    
    while True:
        print("\nAvailable crops:")
        all_crops = rotation_graph.get_all_crops()
        # Print in columns for better readability
        col_width = max(len(crop) for crop in all_crops) + 2
        num_cols = 3
        for i in range(0, len(all_crops), num_cols):
            row = all_crops[i:i+num_cols]
            print("".join(crop.ljust(col_width) for crop in row))
        
        previous_crop = input("\n👉 What was the last crop planted? ")
        if previous_crop.lower() == 'q':
            break
            
        if previous_crop not in all_crops:
            print(f"⚠️ Crop '{previous_crop}' not found in the database")
            continue
        
        time_choice = input("Enter 1 for month or 2 for season: ")
        if time_choice.lower() == 'q':
            break
            
        if time_choice == '1':
            month = input("📅 Current month (1-12): ")
            if month.lower() == 'q':
                break
                
            try:
                month = int(month)
                if month < 1 or month > 12:
                    print("⚠️ Month must be between 1 and 12")
                    continue
                    
                recommendations = rotation_graph.recommend_next_crop(
                    previous_crop, 
                    current_month=month,
                    top_n=5
                )
                
                print(f"\n🌿 Top recommendations for month {month} after {previous_crop}:")
                if not recommendations:
                    print(f"⚠️ No recommendations found for {previous_crop} in month {month}")
                else:
                    for i, (crop, score, reasons) in enumerate(recommendations, 1):
                        print(f"{i}. {crop} (score: {score:.2f})")
                        for reason in reasons:
                            print(f"   - {reason}")
            except ValueError:
                print("⚠️ Please enter a valid number for month")
                
        elif time_choice == '2':
            print("Available seasons: Spring, Summer, Fall, Winter")
            season = input("🕐 Current season: ")
            if season.lower() == 'q':
                break
                
            if season not in ['Spring', 'Summer', 'Fall', 'Winter']:
                print("⚠️ Season must be one of: Spring, Summer, Fall, Winter")
                continue
                
            recommendations = rotation_graph.recommend_next_crop(
                previous_crop, 
                current_season=season,
                top_n=5
            )
            
            print(f"\n🌿 Top recommendations for {season} after {previous_crop}:")
            if not recommendations:
                print(f"⚠️ No recommendations found for {previous_crop} in {season}")
            else:
                for i, (crop, score, reasons) in enumerate(recommendations, 1):
                    print(f"{i}. {crop} (score: {score:.2f})")
                    for reason in reasons:
                        print(f"   - {reason}")
        
        # Ask if they want rotation sequence
        seq_choice = input("\nGenerate optimal rotation sequence? (y/n): ")
        if seq_choice.lower() == 'q':
            break
            
        if seq_choice.lower() == 'y':
            seq_length = input("How many crops in the sequence? (default: 3) ")
            if seq_length.lower() == 'q':
                break
                
            try:
                if seq_length.strip():
                    seq_length = int(seq_length)
                else:
                    seq_length = 3
                    
                if time_choice == '1':
                    sequence = rotation_graph.get_optimal_rotation_sequence(
                        starting_crop=previous_crop,
                        starting_month=month,
                        sequence_length=seq_length
                    )
                else:
                    sequence = rotation_graph.get_optimal_rotation_sequence(
                        starting_crop=previous_crop,
                        starting_season=season,
                        sequence_length=seq_length
                    )
                
                print(f"\n📋 Recommended {len(sequence)}-crop rotation sequence:")
                
                if not sequence:
                    print("⚠️ Could not generate a rotation sequence with the given parameters")
                else:
                    for i, (crop, planting_time) in enumerate(sequence, 1):
                        time_str = f"Month {planting_time}" if isinstance(planting_time, int) else planting_time
                        print(f"{i}. {crop} ({time_str})")
            except ValueError:
                print("⚠️ Please enter a valid number for sequence length")

if __name__ == "__main__":
    main()